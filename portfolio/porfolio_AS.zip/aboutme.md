#Fake Blog Exercies
##Coding Dojo Assignment
###Asingjr2

###Folder includes:
*Fake Blog html
*Fake Blog css
*Fake Blog brainstorming png
*Angular png